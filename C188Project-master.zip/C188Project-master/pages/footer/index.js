const footer = document.querySelector("footer")
footer.innerHTML = `
<div class="section_5--footer d-flex flex-wrap">
        <a>Giới thiệu về HD</a>
        <a>Chính sách mua hàng</a>
        <a>Chính sách đổi trả</a>
        <a>Hướng dẫn kích thước</a>
      </div>
      <p>
        HD Hits DIfferent - He Is Defferent. Giấy phép đăng ký kinh doanh số
        41P8022591. Cấp ngày 31/05/2021 tại Uỷ Ban Nhân Dân quận Ninh Kiều.
      </p>
      <div class="section_2--center">
        <p>Số điện thoại: 08 99 96 97 68</p>
        <p>Email: info.hd@gmail.com</p>
      </div>
      <div class="social d-flex gap-3">
        <a href="" ><i style="font-size:2rem;" class="fa-brands fa-facebook footer_icon"></i></a>
        <a href="" ><i style="font-size:2rem;" class="fa-brands fa-instagram"></i></i></a> 
        
      </div>
`
